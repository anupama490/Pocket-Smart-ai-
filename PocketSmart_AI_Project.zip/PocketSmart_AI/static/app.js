const $ = s => document.querySelector(s);
const money = n => `₹${Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:2})}`;
let state = null;

async function load(){
  state = await fetch('/api/summary').then(r=>r.json());
  const p=state.profile;
  $('#income').textContent=money(p.monthly_income);
  $('#spent').textContent=money(state.total_spent);
  $('#remaining').textContent=money(state.remaining_budget);
  $('#savings').textContent=money(state.potential_savings);
  $('#budgetUsed').textContent=`${money(state.total_spent)} used`;
  $('#budgetTotal').textContent=`${money(p.monthly_budget)} budget`;
  const pct=p.monthly_budget?state.total_spent/p.monthly_budget*100:0;
  $('#budgetPct').textContent=`${pct.toFixed(1)}%`;
  $('#budgetBar').style.width=`${Math.min(100,Math.max(0,pct))}%`;
  $('#expenseRows').innerHTML=state.expenses.length?state.expenses.map(e=>`<tr><td>${e.spent_on}</td><td>${escapeHtml(e.title)}</td><td>${escapeHtml(e.category)}</td><td>${money(e.amount)}</td><td><button class="delete" onclick="removeExpense(${e.id})">Delete</button></td></tr>`).join(''):`<tr><td colspan="5">No expenses yet.</td></tr>`;
  $('#insights').innerHTML=[
    ['Top category', state.top_category==='None'?'Add expenses to see patterns.':`${state.top_category} is currently your largest category.`],
    ['Budget status', pct>100?`You are ${money(state.total_spent-p.monthly_budget)} over budget.`:`You still have ${money(state.remaining_budget)} available.`],
    ['Savings goal', state.potential_savings>=p.savings_goal?`Current records leave enough room for your ${money(p.savings_goal)} goal.`:`You need ${money(p.savings_goal-state.potential_savings)} more room to reach the goal.`]
  ].map(x=>`<div class="insight"><strong>${x[0]}</strong><span>${x[1]}</span></div>`).join('');
}
function escapeHtml(v){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}

$('#spentOn').value=new Date().toISOString().slice(0,10);
$('#expenseForm').addEventListener('submit',async e=>{e.preventDefault();const body={title:$('#title').value,category:$('#category').value,amount:$('#amount').value,spent_on:$('#spentOn').value};const r=await fetch('/api/expenses',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!r.ok){alert((await r.json()).error||'Could not add expense');return}e.target.reset();$('#spentOn').value=new Date().toISOString().slice(0,10);load();});
async function removeExpense(id){await fetch(`/api/expenses/${id}`,{method:'DELETE'});load();}window.removeExpense=removeExpense;

$('#askForm').addEventListener('submit',async e=>{e.preventDefault();const q=$('#question').value.trim();if(!q)return;$('#chat').insertAdjacentHTML('beforeend',`<div class="bubble user">${escapeHtml(q)}</div>`);$('#question').value='';const r=await fetch('/api/assistant',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:q})});const data=await r.json();$('#chat').insertAdjacentHTML('beforeend',`<div class="bubble ai">${escapeHtml(data.answer)}</div>`);$('#chat').scrollTop=$('#chat').scrollHeight;});

$('#openProfile').onclick=()=>{const p=state.profile;$('#pIncome').value=p.monthly_income;$('#pBudget').value=p.monthly_budget;$('#pGoal').value=p.savings_goal;$('#profileDialog').showModal();};
$('#closeProfile').onclick=()=>$('#profileDialog').close();
$('#profileForm').addEventListener('submit',async e=>{e.preventDefault();await fetch('/api/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({monthly_income:$('#pIncome').value,monthly_budget:$('#pBudget').value,savings_goal:$('#pGoal').value})});$('#profileDialog').close();load();});
load();
