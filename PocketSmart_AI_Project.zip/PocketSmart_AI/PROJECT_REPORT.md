# Project Report: PocketSmart AI

## 1. Project Title
**PocketSmart AI: Your Smart Budget & Recommendation Assistant**

## 2. Technology Track
Generative AI with Google

## 3. Problem Statement
Many users record expenses but still struggle to understand how their daily spending affects their monthly budget and savings target. PocketSmart AI combines expense tracking with personalized, conversational recommendations.

## 4. Objective
Build a simple budgeting web application that records expenses, monitors budget usage, estimates savings, identifies high-spending categories, and uses Google Gemini to answer budget-related questions using the user's own recorded data.

## 5. Main Modules
- User budget profile
- Expense manager
- Dashboard analytics
- Smart recommendation engine
- Gemini-powered assistant
- SQLite persistence

## 6. Architecture
Browser UI → Flask REST API → SQLite database

For assistant requests:
Browser → Flask → Gemini API (when key is available) → response to browser

A local recommendation engine is used when Gemini is not configured.

## 7. Input
- Monthly income
- Monthly spending budget
- Monthly savings goal
- Expense title
- Expense category
- Expense amount
- Expense date
- Natural-language user question

## 8. Output
- Total expenses
- Remaining monthly budget
- Potential monthly savings
- Budget utilization percentage
- Highest-spending category
- Personalized recommendations
- Conversational AI response

## 9. Technologies
Python, Flask, SQLite, HTML, CSS, JavaScript, Google Gemini API.

## 10. Future Enhancements
- Authentication
- Monthly filtering
- Charts and downloadable reports
- Recurring expenses
- Receipt scanning
- Bank transaction import
- Multi-user cloud database
- Spending anomaly detection

## 11. Conclusion
PocketSmart AI demonstrates how Generative AI can be combined with conventional financial tracking to make a budgeting application more interactive and personalized. The system is usable even without Gemini and can be upgraded to Gemini mode by adding an API key.
