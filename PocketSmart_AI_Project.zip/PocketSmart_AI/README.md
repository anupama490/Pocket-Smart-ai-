# PocketSmart AI — Smart Budget & Recommendation Assistant

A complete student project for the **Generative AI with Google** track.

## Features
- Monthly income, budget, and savings-goal setup
- Add and delete expenses
- Persistent SQLite database
- Budget usage dashboard
- Category-based smart insights
- Savings progress guidance
- AI chat assistant
- Optional Google Gemini integration
- Local fallback recommendations when no API key is configured
- Responsive web interface

## Tech Stack
- Python 3
- Flask
- SQLite
- HTML, CSS, JavaScript
- Google Gemini via `google-genai`

## Run the project

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

Open: `http://127.0.0.1:5000`

## Enable Gemini

Set the environment variable before starting the app.

### Windows PowerShell
```powershell
$env:GEMINI_API_KEY="YOUR_KEY"
python app.py
```

### macOS/Linux
```bash
export GEMINI_API_KEY="YOUR_KEY"
python app.py
```

If the key is not set, the project still works using a built-in rule-based recommendation engine.

## Project Flow
1. User configures monthly income, monthly spending budget, and savings target.
2. User records expenses by title, category, amount, and date.
3. Flask stores transactions in SQLite.
4. Dashboard calculates spending, budget remaining, potential savings, and largest category.
5. Smart Insights generates immediate recommendations from the stored data.
6. The assistant receives the user's financial summary and question.
7. If `GEMINI_API_KEY` exists, Gemini produces the response; otherwise PocketSmart returns a local recommendation.

## Suggested Demo
1. Set income to ₹50,000, budget to ₹30,000, and savings goal to ₹10,000.
2. Add Food ₹4,000, Travel ₹2,500, Shopping ₹6,000 and Bills ₹5,000.
3. Show budget usage and Smart Insights.
4. Ask: “How can I save more this month?”
5. Demonstrate Gemini mode if an API key is configured.

## Notes
This is an educational budgeting assistant. It provides general budgeting suggestions and is not professional financial advice.
