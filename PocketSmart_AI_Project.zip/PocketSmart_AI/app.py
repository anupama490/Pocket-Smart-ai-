import os
import sqlite3
from datetime import date
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
DB_PATH = os.path.join(os.path.dirname(__file__), 'pocketsmart.db')


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS profile (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        monthly_income REAL NOT NULL DEFAULT 50000,
        monthly_budget REAL NOT NULL DEFAULT 30000,
        savings_goal REAL NOT NULL DEFAULT 10000
    );
    INSERT OR IGNORE INTO profile(id, monthly_income, monthly_budget, savings_goal)
    VALUES(1, 50000, 30000, 10000);

    CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        amount REAL NOT NULL,
        spent_on TEXT NOT NULL
    );
    ''')
    conn.commit()
    conn.close()


def get_profile():
    conn = db()
    row = conn.execute('SELECT * FROM profile WHERE id=1').fetchone()
    conn.close()
    return dict(row)


def get_expenses():
    conn = db()
    rows = conn.execute('SELECT * FROM expenses ORDER BY spent_on DESC, id DESC').fetchall()
    conn.close()
    return [dict(r) for r in rows]


def summary():
    p = get_profile()
    expenses = get_expenses()
    total = sum(x['amount'] for x in expenses)
    remaining_budget = p['monthly_budget'] - total
    potential_savings = p['monthly_income'] - total
    by_category = {}
    for x in expenses:
        by_category[x['category']] = by_category.get(x['category'], 0) + x['amount']
    top_category = max(by_category, key=by_category.get) if by_category else 'None'
    return {
        'profile': p,
        'expenses': expenses,
        'total_spent': round(total, 2),
        'remaining_budget': round(remaining_budget, 2),
        'potential_savings': round(potential_savings, 2),
        'by_category': by_category,
        'top_category': top_category
    }


def local_advice(message, s):
    p = s['profile']
    spent = s['total_spent']
    budget = p['monthly_budget']
    pct = (spent / budget * 100) if budget else 0
    savings = s['potential_savings']
    top = s['top_category']
    msg = (message or '').lower()

    if 'save' in msg or 'saving' in msg:
        return f"You currently have ₹{savings:,.0f} left after recorded expenses. Your target is ₹{p['savings_goal']:,.0f}. Consider moving savings first, then spending the remainder."
    if 'budget' in msg:
        return f"You have used {pct:.1f}% of your ₹{budget:,.0f} monthly budget. Remaining budget: ₹{s['remaining_budget']:,.0f}."
    if 'category' in msg or 'spend' in msg:
        return f"Your highest recorded spending category is {top}. Review that category first for the easiest reductions."
    if spent > budget:
        return f"Recorded spending is ₹{spent-budget:,.0f} above your monthly budget. Freeze non-essential purchases and review {top} spending first."
    return f"You have spent ₹{spent:,.0f} so far and have ₹{s['remaining_budget']:,.0f} left in your budget. Your biggest category is {top}."


def gemini_advice(message, s):
    key = os.getenv('GEMINI_API_KEY')
    if not key:
        return None
    try:
        from google import genai
        client = genai.Client(api_key=key)
        prompt = f"""You are PocketSmart AI, a concise personal budgeting assistant.
Give practical, non-judgmental money management suggestions based only on the user's recorded data.
Do not claim to be a financial advisor. Keep the answer under 120 words.

Monthly income: ₹{s['profile']['monthly_income']}
Monthly budget: ₹{s['profile']['monthly_budget']}
Savings goal: ₹{s['profile']['savings_goal']}
Total recorded spending: ₹{s['total_spent']}
Remaining budget: ₹{s['remaining_budget']}
Category totals: {s['by_category']}
User question: {message}
"""
        response = client.models.generate_content(model='gemini-2.5-flash', contents=prompt)
        return response.text.strip() if response.text else None
    except Exception:
        return None


@app.route('/')
def index():
    return render_template('index.html')


@app.get('/api/summary')
def api_summary():
    return jsonify(summary())


@app.post('/api/profile')
def update_profile():
    data = request.get_json(force=True)
    vals = [float(data.get(k, 0)) for k in ('monthly_income', 'monthly_budget', 'savings_goal')]
    conn = db()
    conn.execute('UPDATE profile SET monthly_income=?, monthly_budget=?, savings_goal=? WHERE id=1', vals)
    conn.commit(); conn.close()
    return jsonify({'ok': True})


@app.post('/api/expenses')
def add_expense():
    data = request.get_json(force=True)
    title = str(data.get('title', '')).strip()
    category = str(data.get('category', 'Other')).strip() or 'Other'
    amount = float(data.get('amount', 0))
    spent_on = str(data.get('spent_on') or date.today().isoformat())
    if not title or amount <= 0:
        return jsonify({'error': 'Title and a positive amount are required.'}), 400
    conn = db()
    conn.execute('INSERT INTO expenses(title, category, amount, spent_on) VALUES(?,?,?,?)',
                 (title, category, amount, spent_on))
    conn.commit(); conn.close()
    return jsonify({'ok': True})


@app.delete('/api/expenses/<int:expense_id>')
def delete_expense(expense_id):
    conn = db()
    conn.execute('DELETE FROM expenses WHERE id=?', (expense_id,))
    conn.commit(); conn.close()
    return jsonify({'ok': True})


@app.post('/api/assistant')
def assistant():
    data = request.get_json(force=True)
    message = str(data.get('message', '')).strip()
    s = summary()
    answer = gemini_advice(message, s) or local_advice(message, s)
    return jsonify({'answer': answer, 'mode': 'Gemini' if os.getenv('GEMINI_API_KEY') else 'Local fallback'})


if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='127.0.0.1', port=5000)
